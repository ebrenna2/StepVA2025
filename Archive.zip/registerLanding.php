<html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="lib/jquery-1.9.1.js"></script>
        <link rel="stylesheet" href="css/base.css" type="text/css">
        <script src="css/header.js"></script>
        <link rel="icon" type="image/x-icon" href="images/cropped-logo.png">    <title>Step VA | Register</title>
</head>
<body>
    <!-- This looks really, really great!  -Thomas -->



    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


<header>

    
        <nav>
            <span id="nav-top">
                <span class="logo">
                    <img src="images/stepvalogo.png">
                    <span id="vms-logo"> Step VA New Account Sign Up </span>
                </span>
                <img id="menu-toggle" src="images/menu.png">
            </span>
            <ul>
                <li><a href="login.php">Log in</a></li>
            </ul>
        </nav></header><h1>Step VA New Account Sign Up</h1>
<main class="signup-form">
    <form class="signup-form" method="post"> </form>
    <form action="registerVolunteer.php" method="get">
        <button type="submit">Volunteer</button>
    </form>
    <br>
    <form action="registerParticipantAndFamilyLeader.php" method="get">
        <button type="submit">Participant</button>
    </form>
</main>
</body></html>