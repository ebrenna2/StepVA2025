<!DOCTYPE html>
<html>
<head>
    <?php require_once('universal.inc'); ?>
    <title>Step VA | Event Attendance</title>
    <link rel="stylesheet" href="css/hours-report.css">
</head>
<body>
    <?php require_once('header.php'); ?>
    <h1>Event Attendance Report</h1>
</body>
</html>